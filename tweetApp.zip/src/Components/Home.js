import { Link } from "react-router-dom";
import TweetCard from "./TweetCard";
import Tweet from "./TweetCard";

const Home = () => {
    return ( 
        <div className="container">
            <h1 className="mt-5 pt-3" >Welcome to the Tweet App</h1>
            <hr />
            <div>
                {/* <Link to="/">Home</Link> */}
                {/* <div className="d-flex justify-content-center mb-2"><TweetCard/></div> */}
                <Link className="btn btn-secondary mx-2" to="/addTweet">Add Tweet</Link>
                <Link className="btn btn-secondary" to="/allTweets">All Tweets</Link>
            </div>
        </div>
     );
}
 
export default Home;