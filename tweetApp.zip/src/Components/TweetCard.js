import React from 'react';
import { useState, useEffect } from 'react';
import Axios from 'axios';
// import Replies from './Replies';
import { Link } from 'react-router-dom';

const TweetCard = (props) => {

  const [replies, setReplies] = useState(false);
  const token = localStorage.getItem('theToken');

  const thetweet = props.thetweet;
  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "long", day: "numeric" }
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-GB', { dateStyle: 'short', timeStyle: 'long' }).format(date)
  }

  const [tweet] = useState({
    tweetId: thetweet.tweetId,
    text: thetweet.text,
    user: thetweet.user,
    lastModified: thetweet.lastModified,
  });

  const [user, setUser] = useState({   //call api through user_id
    firstName: "puru",
    lastName: "gupta",
    userName: "",
    email: "purgupta@gmail.com"
  });

  useEffect(() => {
    getUser();
    // getTags();
  }, [])

  function getUser() {
    Axios.get(`http://localhost:7002/api/v1.0/tweetApp/user/search/${tweet.userName}`,
      { headers: { Authorization: token } }
    ).then(res => {
      let user = res.data;
      setUser(user);
    }).catch(err => {
      console.log(err);
    })
  }

  function Avatar() {
    return (
      <img
        src='https://t3.ftcdn.net/jpg/03/46/83/96/360_F_346839683_6nAPzbhpSkIpb8pmAwufkC7c5eD7wYws.jpg'
        alt='avatar'
        className='avatar'
      />
    );
  }

  function message() {
    return (
      <div className="message">{tweet.text}</div>
    );
  }

  function nameWithHandle() {
    return (
      <span className="name-with-handle">
        <span className="name">{tweet.user.firstName} {tweet.user.lastName}</span>
        <span className="handle">@{tweet.user.userName}</span>
      </span>
    );
  }

  const time = () => <span className="time">{formatDate(tweet.lastModified)}</span>;
  const CommentButton = () => <i className="far fa-comment" />;
  // const RetweetButton = () => <i className="fa fa-retweet retweet-button" />;
  const LikeButton = () => <i className="fa fa-heart like-button" />;
  // const ShareButton = () => <i className="fas fa-external-link-alt" />;


  return (
    <div className="tweet">
      {/* {avatar()} */}
      <Avatar/>
      <div className="content">
        {nameWithHandle()} {time()}
        {message()}
        <div className="button">
          <CommentButton />
          {/* <RetweetButton /> */}
          <LikeButton />
          {/* <ShareButton /> */}
        </div>
      </div>
    </div>
  );
}

export default TweetCard;
