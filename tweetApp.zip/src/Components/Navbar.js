import React, {useState,setState} from 'react';
import { Link } from "react-router-dom";
import  { useNavigate } from 'react-router-dom';
import Logout from './Logout';

const Navbar=()=>{
    return(
        <div>
        <nav class="navbar fixed-top navbar-expand-lg navbar-light" style={{backgroundColor: "#e3f2fd"}} >
  <a class="navbar-brand font-weight-bold" href="#">Tweet App</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" >
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="/">Home<span class="sr-only">(current)</span></a>
      </li>
      {/* <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li> */}
    </ul>
    <form class="form-inline my-2 my-lg-0">
    <a class="btn btn-primary nav-link text-light" href="/login">Login</a>
    <a class="btn btn-primary mx-2 nav-link text-light" href="/register">Register</a>
    <a class="btn btn-danger nav-link text-light" onClick={Logout()} href="/login">Logout</a>
    </form>
  </div>
</nav>
</div>
    );
}

export default Navbar;