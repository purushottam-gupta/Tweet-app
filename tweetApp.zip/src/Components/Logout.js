import React, {useState,setState} from 'react';
import { Link } from "react-router-dom";
// import  { useNavigate } from 'react-router-dom';

const Logout=()=>{
    // let navigate = useNavigate();
    // localStorage().clear();
    // navigate("../", { replace: true });
}

export default Logout