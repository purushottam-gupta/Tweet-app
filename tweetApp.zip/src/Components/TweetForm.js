import React, { useState } from "react";
// import { Button, InputLabel, Input, TextField } from "@material-ui/core";
// import { Add, Remove } from "@material-ui/icons";
import Axios from 'axios';
import  { useNavigate } from 'react-router-dom';
// import Alert from '@mui/material/Alert';

import jwt_decode from "jwt-decode";

// const maxInputFields = 10;
// const defaultNumberOfFields = 1;

function TweetForm() {
    let navigate = useNavigate();
    const token = localStorage.getItem('theToken');
    var decoded = jwt_decode(token);
    var tokenUsername = decoded.sub;
    const [success, setSuccess] = useState(false);
    // const [numberOfFields, setNumberOfFields] = useState(defaultNumberOfFields);
    const [tweet, setTweet] = useState({
        tweetId: "",
        content: "",
        likes:0
    })

//     // function generateInputField(index) {
//     //     return (
//     //         <div key={index} style={{ paddingBottom: "10px" }}>
//     //             <Input variant="outlined" type="text" value={tags.tag} onChange={(e) => handleChange(e, index - 1)} />
//     //         </div>
//     //     );
//     // }

//     // function generateFields() {
//     //     let listOfFields = [];
//     //     for (let i = 1; i <= numberOfFields; i++) {
//     //         listOfFields.push(generateInputField(i));
//     //     }
//     //     return listOfFields;
//     // }

//     function handleAdd() {
//         if (numberOfFields < maxInputFields) {
//             setNumberOfFields(numberOfFields + 1);
//             // setTags([...tags, { tag: "" }]);
//         }

//     }
//     // function handleRemove(index) {
//     //     if (numberOfFields > 1) {
//     //         setNumberOfFields(numberOfFields - 1);
//     //         const list = [...tags];
//     //         list.splice(index, 1);
//     //         // setTags(list);
//     //     }
//     // }
//     // function handleChange(e, index) {
//     //     const list = [...tags];
//     //     // list[index]["tag"] = e.target.value;
//     //     // setTags(list);
//     // }


    function addTweet() {
        Axios.post(
            `http://localhost:7001/api/v1.0/tweetApp/add/${tokenUsername}`,
            tweet,
            { headers: { Authorization: token } }
        ).then(
            res => {
                const tweetData = res.data;
                console.log(res.data);
                setTweet(tweetData);
                navigate("../allTweets", { replace: true });
            }
        ).catch(
            error => {
                console.log(error);
            }
        )
    }

//     // function addTags() {
//     //     tags.map((stag) => {
//     //         // console.log(tweet.tweet_id);
//     //         Axios.post(
//     //             `http://localhost:1000/api/add/hashtag/${tweet.tweet_id}`,
//     //             stag,
//     //             { headers: { Authorization: token } }
//     //         ).then(
//     //             res => {
//     //                 // console.log(res.data);
//     //                 setTweet({
//     //                     tweet_id: "",
//     //                     content: "",
//     //                     is_reply: 1
//     //                 });
//     //                 setSuccess(!success);
//     //             }
//     //         ).catch(
//     //             error => {
//     //                 console.log(error);
//     //             }
//     //         );
//     //         return true;
//     //     })
//     // }

    return (
        <>
            {/* <Navbar /> */}
            <div className="container">
                {/* <div style={{ display: `${!success ? "none" : ""}` }} ><div class="alert alert-success" role="alert">
  A simple success alert—check it out!
</div></div> */}
               <h1 className="mt-5 pt-3">Add Tweet</h1>
                <div style={{ paddingBottom: "10px", paddingTop: "10px" }}>
                     {/* <TextField variant="outlined" label="Content" value={tweet.content} onChange={(e) => setTweet({ ...tweet, text: e.target.value })} /> */}
                    <input type="text"
                     className="form-control w-50 mx-auto my-2"
                     placeholder="Enter tweet message"
                     value={tweet.text}
                     onChange={(e) => setTweet({ ...tweet, text: e.target.value })}
                    />
                </div>
                <div style={{ paddingBottom: "10px", paddingTop: "10px" }}>
                    <input type="text"
                     className="form-control w-50 mx-auto my-2"
                     placeholder="enter related tags"
                     value=""
                    />
                </div>
                 {/* <InputLabel>Tags</InputLabel>
                {generateFields()}
                {numberOfFields < maxInputFields && (
                    <Button variant="contained" color="primary" onClick={handleAdd}>
                        <Add />
                    </Button>
                )} */}
                 {/* {numberOfFields > 1 && (
                    <Button style={{ marginLeft: "10px" }} variant="contained" color="primary" onClick={() => handleRemove(numberOfFields - 1)}>
                        <Remove />
                    </Button>
                )} */}
            </div>
            <button type="submit" className="btn btn-primary my-3" onClick={addTweet}>Submit</button>
             {/* <button type="submit" className="btn btn-primary my-3" onClick={addTags}>Add tags</button> */}
        </>
    );
}


export default TweetForm;