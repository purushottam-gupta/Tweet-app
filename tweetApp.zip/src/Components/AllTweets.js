import React from 'react';
import { useState,useEffect } from 'react';
import Axios from 'axios';
import TweetCard from './TweetCard';

function AllTweets() {
    const [tweets, setTweets] = useState([]);
    const token = localStorage.getItem('theToken');

    useEffect(()=>{
        getAllTweets();
    }, [])

    function getAllTweets(){
        Axios.get("http://localhost:7001/api/v1.0/tweetApp/all",
        { headers: { Authorization: token } }
        ).then(res => {
            const dt = res.data;
            setTweets(dt);
        }).catch(err => {
            console.log(err);
        })
    }
    // console.log(tweets);

    return(
        <div className="container">
            <h1 className='text-secondary mt-5 pt-3'>Tweets</h1>
            {tweets.map((thetweet, index) => (
                <div key={index} >
                    <div className="d-flex justify-content-center m-2"><TweetCard thetweet= {thetweet}/></div>
                </div>
            ))}
        </div>
    );
}

export default AllTweets;

// import { Component } from "react";
// import axios from 'axios';

// export default class AllTweets extends Component{


//     componentDidMount = async()=>{
//         const allTweetsUrl = "http://localhost:7001/api/v1.0/tweetApp/all"
//         try{
//             let res = await axios.get(allTweetsUrl,{ headers: { Authorization: token } });
//             let tweetArray = res.data;
//             let username;
//             let tweetContent;
//             let likeCount;
//             let s = "";
//             for(let i=0;i<tweetArray.length;i++){
//                 let getUserByIDUrl = "http://localhost:7002/api/v1.0/tweetApp/user/search/" + tweetArray[i].user.userName;
//                 try{
//                     res = await axios.get(getUserByIDUrl);
//                     username = res.data.userName;
//                 }
//                 catch(err){
//                     console.log(err);
//                 }
//                 tweetContent = tweetArray[i].text;
//                 likeCount = tweetArray[i].likes;
//                 s = s + `<center>
//                             <p>${username}</p>
//                             <p>Tweeted : ${tweetContent}</p>
//                             <p>Likes : ${likeCount} </p>
//                         </center>
//                         <hr/>`
//             }

//             document.getElementById('main-div').innerHTML = "<center><h6>Recent Tweets<h6></center><hr/>" + s;
//         }
//         catch(err){

//         }


//     }

//     render(){
//         return(
//             <div id="main-div" style={{width:"50%",margin:"3% auto",border:"1px solid black"}}>

//             </div>
//         );
//     }

// }